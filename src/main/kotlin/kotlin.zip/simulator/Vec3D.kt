package simulator

import kotlin.math.hypot

data class Vec3D(var x: Double = 0.0, var y: Double = 0.0, var z: Double = 0.0) {
    operator fun plus(other: Vec3D) =
            Vec3D(x + other.x, y + other.y, z + other.z)

    operator fun minus(other: Vec3D) =
            Vec3D(x - other.x, y - other.y, z - other.z)

    operator fun times(other: Double) =
            Vec3D(x * other, y * other, z * other)

    operator fun div(other: Double) =
            Vec3D(x / other, y / other, z / other)

    operator fun rem(other: Vec3D) =
            x * other.x + y * other.y + z * other.z

    val length: Double
        get() = hypot(hypot(x, y), z)

    val normalized: Vec3D
        get() = this / length

    fun clamp(max: Double): Vec3D =
            if (length > max)
                normalized * max
            else
                this
}
